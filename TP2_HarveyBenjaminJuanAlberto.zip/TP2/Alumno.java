/** Una clase Alumno que nos permite ingresar sus datos, notas, calcular su promedio, determinar si aprobo, etc.
 *
 * @author      Hardoy - Harvey 
 * @version     24/08/2025
 */
public class Alumno
{
    // instance variables
    private int lu;
    private String nombre;
    private String apellido;
    private double nota1;
    private double nota2;
    
    /**
     * @param   p_lu        Libreta universitaria del alumno
     * @param   p_nombre    nombre del alumno
     * @param   p_apellido  apellido del alumno
     */
    Alumno(int p_lu, String p_nombre, String p_apellido)
    {
        // initialise instance variables
        setLU(p_lu);
        setNombre(p_nombre);
        setApellido(p_apellido);
        nota1 = 0.0;
        nota2 = 0.0;
    }

    //Setters
    private void setLU(int p_lu){
        lu = p_lu;
    }
    private void setNombre(String p_nombre){
        nombre = p_nombre;
    }
    private void setApellido(String p_apellido){
        apellido = p_apellido;
    }
    public void setNota1(double p_nota1){
        nota1 = p_nota1;
    }
    public void setNota2(double p_nota2){
        nota2 = p_nota2;
    }
    
    //Getters
    public int getLU(){
        return lu;
    }
    public String getNombre(){
        return nombre;
    }
    public String getApellido(){
        return apellido;
    }
    public double getNota1(){
        return nota1;
    }
    public double getNota2(){
        return nota2;
    }
    
    /** Metodo que nos permite calcular el promedio en base a las notas
     * @return double
     */
    public double promedio(){
        return (getNota1() + getNota2()) / 2.0;
    }
    
    /** Metodo que devuelve true si el alumno cumplio las condiciones para aprobar o false si no lo hizo
     * @return boolean
     */
    public boolean aprueba(){
        return (promedio() >= 7 && getNota1() > 6 && getNota2() > 6);
    }
    
    /** Metodo que devuelve un texto para avisar si el alumno aprobo o no la mteria
     * @return String
     */
    public String leyendaAprueba(){
        if(aprueba()){
            return "APROBADO";
        }
        else{
            return "DESAPROBADO";
        }
    }
    
    /** Metodo para concatenar nombre y apellido
     * @return String
     */  
    public String nomYApe(){
        return getNombre() + " " + getApellido(); 
    } 

    /** Metodo para concatenar apellido y nombre
     * @return String
     */    
    public String apeYNom(){
         return getApellido() + " " + getNombre();   
    }
    
    /** Metodo para mostrar los datos, notas, promedio y si aprobo o no el alumno
     * 
     */
    public void mostrar(){
        System.out.println("Nombre y Apellido: " + nomYApe());
        System.out.println("LU: " + getLU() + " " + "Notas: " + getNota1() + "-" + getNota2());
        System.out.println("Promedio: " + promedio() + "-" + leyendaAprueba());
    }
    
    
    
    
    
    
}