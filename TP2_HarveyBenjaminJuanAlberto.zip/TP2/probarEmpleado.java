
/**
 * Write a description of class probarEmpleado here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class probarEmpleado
{
    public static void main(String[] args){
        Empleado nuevoEmpleado = new Empleado(2045526737, "Benjamin", "Harvey", 450000, 2014);
        nuevoEmpleado.mostrar();
    }
}