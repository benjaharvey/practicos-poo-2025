
/**
 * Write a description of class probarLaboratorio here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class probarLaboratorio
{
    public static void main(String[] args){
            Laboratorio prueba = new Laboratorio("Benja S.A", "Antartida Argentina 1189", "54-11-3794004039");
            prueba.mostrar();
    }
}